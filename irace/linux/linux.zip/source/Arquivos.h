
void le_arquivo(char nomearq[], float *tempo, int *m, int *p, int **vetor_pesos);
