/* Menu principal */
int menu_principal(void);


/* Menu Algoritmos Geneticos */
int menu_AG(void);





