
struct item_peso {
    int id_item;
    int valor;
};

